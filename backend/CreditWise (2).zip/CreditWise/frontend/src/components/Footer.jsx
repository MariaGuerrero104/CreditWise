import React from "react";

function Footer() {
  return (
    <footer>
      <p>© 2025 CreditWise. Todos los derechos reservados.</p>
    </footer>
  );
}

export default Footer;
